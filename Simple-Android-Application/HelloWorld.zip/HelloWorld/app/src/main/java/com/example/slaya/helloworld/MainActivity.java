package com.example.slaya.helloworld;

import android.content.res.ColorStateList;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.graphics.Color;
import android.widget.RelativeLayout;
import android.widget.TextView;





public class MainActivity extends AppCompatActivity {
    public TextView colorOutput;
    private EditText boxOtext;
    private Button button;
    private Button switcheroo1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Assign values to the nodes used
        colorOutput = (TextView) findViewById(R.id.colorOutput);
        boxOtext = (EditText) findViewById(R.id.textView3);
        button = (Button) findViewById(R.id.button);
        switcheroo1 = (Button) findViewById(R.id.switcheroo1);

        //Adjust the position of the color information field


        //Create an action for the button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeColor(boxOtext);//Branches to changeColor, which changes the color and updates the RGB values
            }
    });
       final Intent intent = new Intent(this, drawingBoard.class);
        switcheroo1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }
    protected void changeColor(EditText a){
        int ALPHA = (int) Math.round(Math.random() * 255);
        int r = (int) Math.round(Math.random() * 255);
        int g = (int) Math.round(Math.random() * 255);
        int b = (int) Math.round(Math.random() * 255);
        int theColor = Color.argb(ALPHA,r,g,b);
        String colorHTML= Integer.toHexString(theColor/2/2/2/2/2/2/2/2);
        a.setTextColor(theColor);
        updateValues(colorHTML, r,g,b);
        return;
    }
    protected void updateValues(String colorHTML, int r, int g, int b){
    colorOutput.setText(r + "r, " + g + "g, " + b + "b, #" + colorHTML );
}

}
