package com.example.slaya.helloworld;

import android.graphics.Color;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.content.Intent;

public class ChooseColour extends AppCompatActivity {
    //Establish all entities used in this view
    private TextView header;
    private SeekBar sliderRed;
    private SeekBar sliderGreen;
    private SeekBar sliderBlue;
    private Button confirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_colour);

        //Link all the entities

         header = (TextView) findViewById(R.id.header);
        sliderRed = (SeekBar) findViewById(R.id.sliderRed);
       sliderGreen = (SeekBar) findViewById(R.id.sliderGreen);
        sliderBlue = (SeekBar) findViewById(R.id.sliderBlue);
     confirm = (Button) findViewById(R.id.confirm);



        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int alpha = 125;
                int r = sliderRed.getProgress();
                int g = sliderGreen.getProgress();
                int b = sliderBlue.getProgress();
                int theColor = Color.argb(alpha,r,g,b);
                Intent intent = new Intent();
                intent.putExtra("message", theColor);
               setResult(RESULT_OK, intent);
             finish();
           }
        });


    }

}
