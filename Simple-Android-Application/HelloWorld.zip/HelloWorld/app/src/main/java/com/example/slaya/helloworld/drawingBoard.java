package com.example.slaya.helloworld;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.AttributeSet;
import android.view.View;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.widget.Button;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Random;

public class drawingBoard extends AppCompatActivity {
   private Button chooseColor;
   private Button clear;
   public CanvasView cv;
   private Button saveDrawing;
   private Button backToMain;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawing_board);

        //Establish identities for the buttons -- make sure to put the canvasview in here when done
        chooseColor = (Button) findViewById(R.id.chooseColor);
        clear = (Button) findViewById(R.id.clear);
        saveDrawing = (Button) findViewById(R.id.Save);
        backToMain = (Button) findViewById(R.id.switcheroo2);
        cv = (CanvasView) findViewById(R.id.canvas);

        //Set Actions for the buttons
        final Intent intent = new Intent(this, ChooseColour.class);

        chooseColor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivityForResult(intent, 1);

            }
        });



        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cv.clearCanvas();
            }
        });



        saveDrawing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               saveDrawing();
            }
        });


        backToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
                  if (resultCode == RESULT_OK) {
                int returnedColor = data.getIntExtra("message",1 );
                cv.changeColor(returnedColor);


            }
        }
        public void saveDrawing() {//Saves file, providing there is a "/Phone/" path

            cv.setDrawingCacheEnabled(true);
            Bitmap b = cv.getDrawingCache();
            File file = new File("/Phone/image" +Math.random()*1000 + ".jpg");
            try{
            file.createNewFile();
            b.compress(CompressFormat.JPEG, 95, new FileOutputStream(file));
            } catch (Exception e){

            }
        }
    }





