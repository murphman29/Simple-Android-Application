package com.example.slaya.helloworld;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class CanvasView extends View {
   public int width;
   public int height;
   private Bitmap bit;
   private Canvas canvas;
   private Path path;
   private Paint paint;
   private float x, y;
   private static final float tolerance = 5;
   Context context;
   public CanvasView (Context context, AttributeSet attributes) {
       super(context, attributes);
       this.context = context;
       path = new Path();
       paint = new Paint();
       paint.setAntiAlias(true);
       paint.setColor(Color.BLUE);
       paint.setStyle(Paint.Style.STROKE);
       paint.setStrokeWidth(4f);

   }
   public void changeColor (int r, int g, int b){
       int ALPHA = (int) Math.round(Math.random() * 255);
       int theColor = Color.argb(ALPHA,r,g,b);
       String colorHTML= Integer.toHexString(theColor/2/2/2/2/2/2/2/2);
       paint.setColor(theColor);
          }

          public void changeColor(int colorCode){
         paint.setColor(colorCode);
          }
   public void onStartTouch(float xAlt, float yAlt){
       path.moveTo(xAlt,yAlt);
       x = xAlt;
       y = yAlt;
   }
   public void moveTouch(float xAlt, float yAlt){
       float dx = Math.abs(xAlt - x);
       float dy = Math.abs(yAlt - y);
       if(dx >= tolerance || dy >= tolerance){
           path.quadTo(x, y, (x+xAlt)/2, (y+yAlt)/2);
           x = xAlt;
           y = yAlt;
       }
   }
   public void upTouch(){
       path.lineTo(x,y);
   }

   public void clearCanvas(){
       path.reset();
       invalidate();
   }


   @Override
    public boolean onTouchEvent(MotionEvent event){
       float xAlt = event.getX();
       float yAlt = event.getY();

       switch(event.getAction()) {
           case MotionEvent.ACTION_DOWN:
               onStartTouch(xAlt, yAlt);
               invalidate();
               break;
           case MotionEvent.ACTION_MOVE:
               moveTouch(xAlt, yAlt);
               invalidate();
               break;
           case MotionEvent.ACTION_UP:
               upTouch();
               invalidate();
               break;
       }
       return true;
   }
   @Override
    protected void onDraw(Canvas canvas){
       super.onDraw(canvas);
       canvas.drawPath(path, paint);
   }
}
//Note: This class was implemented with the help of a YouTube tutorial.
